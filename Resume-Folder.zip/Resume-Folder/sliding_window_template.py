def fixed_window(arr, k):
    window_sum = sum(arr[:k])  # Initialize window
    result = [window_sum]  # Store first window's result

    for i in range(k, len(arr)):
        window_sum += arr[i] - arr[i - k]  # Slide the window
        result.append(window_sum)  # Store current window's result
    
    return result
	

def variable_window(arr, target):
    left = 0
    window_sum = 0
    result = float('inf')  # or -inf, depending on the problem

    for right in range(len(arr)):
        window_sum += arr[right]  # Add new element to window

        while window_sum >= target:  # Condition to shrink the window
            result = min(result, right - left + 1)  # Update result
            window_sum -= arr[left]  # Shrink from left
            left += 1

    return result if result != float('inf') else 0

/*
1. Maximum Sum of Subarray of Size K
Problem: Given an array of integers and a number k, find the maximum sum of a subarray of size k.
2. Average of Subarray of Size K
Problem: Given an array of integers and a number k, find the average of each subarray of size k.
3. Sliding Window Maximum
Problem: Given an array and an integer k, find the maximum value in each sliding window of size k.
4. Minimum Size Subarray Sum
Problem: Given an array of integers and a target sum, find the minimal length of a contiguous subarray whose sum is greater than or equal to the target sum.
5. Longest Substring with At Most K Distinct Characters
Problem: Given a string s and an integer k, find the length of the longest substring with at most k distinct characters.
6. Find All Anagrams in a String
Problem: Given two strings s and p, find all the start indices of p's anagrams in s.
7. Count Number of Subarrays with Sum Less Than K
Problem: Given an array of integers and an integer k, find the number of contiguous subarrays whose sum is less than k.
8. Subarray Product Less Than K
Problem: Given an array of integers and an integer k, find the number of contiguous subarrays whose product is less than k.
9. Longest Subarray of 1’s After Deleting One Element
Problem: Given a binary array, find the length of the longest subarray containing only 1’s if you can delete at most one element.
10. K-Concatenation Maximum Sum
Problem: Given an array of integers, you are allowed to concatenate the array at most k times and find the maximum sum of the resulting array.
*/

/*

Fixed Sliding Window:
1)https://leetcode.com/problems/maximum-sum-of-distinct-subarrays-with-length-k/(Leetcode 2461)
2)https://leetcode.com/problems/sliding-subarray-beauty/(Leetcode 2653)
3)https://leetcode.com/problems/maximum-points-you-can-obtain-from-cards/(Leetcode 1423)
4)https://leetcode.com/problems/maximum-average-subarray-i/(Leetcode 643)
5)https://leetcode.com/problems/number-of-sub-arrays-of-size-k-and-average-greater-than-or-equal-to-threshold/(Leetcode 1343)
6)https://leetcode.com/problems/check-if-a-string-contains-all-binary-codes-of-size-k/(Leetcode 1461)
7)https://leetcode.com/problems/find-all-anagrams-in-a-string/(Leetcode 438)
8)https://leetcode.com/problems/permutation-in-string/(Leetcode 567)
9)https://leetcode.com/problems/sliding-window-maximum/(Leetcode 239)
10)https://leetcode.com/problems/substrings-of-size-three-with-distinct-characters/description/(Leetcode 1876)
Variable Sized Sliding Window:
11)https://leetcode.com/problems/find-the-longest-semi-repetitive-substring/(Leetcode 2730)
12)https://leetcode.com/problems/count-the-number-of-good-subarrays/(Leetcode 2537)
13)https://leetcode.com/problems/minimum-consecutive-cards-to-pick-up/(Leetcode 2260)
14)https://leetcode.com/problems/minimum-operations-to-reduce-x-to-zero/(Leetcode 1658)
15)https://leetcode.com/problems/count-number-of-nice-subarrays/(Leetcode 1248)
16)https://leetcode.com/problems/fruit-into-baskets/(Leetcode 904)
17)https://leetcode.com/problems/max-consecutive-ones-iii/(Leetcode 1004)
18)https://leetcode.com/problems/subarray-product-less-than-k/(Leetcode 713)
19)https://leetcode.com/problems/minimum-size-subarray-sum/(Leetcode 209)
20)https://leetcode.com/problems/longest-substring-without-repeating-characters/(Leetcode 3)

*/